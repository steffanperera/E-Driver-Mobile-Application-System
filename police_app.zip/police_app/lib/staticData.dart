class StaticData {
  static String loggeduser = "";
  static String passengerLisence = "";
  static String driverId = "";
}
